const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const router = require('./routes/index');

const relay = express();

relay.use(cors());
relay.use(express.json({ limit: '10mb' }));
relay.use(express.urlencoded({ limit: '10mb', extended: true }));

relay.use('/', router);

exports.handler = serverless(relay, {
  request: function (req, event, context) {
    req.event = event;
    req.context = context;
  },
});
