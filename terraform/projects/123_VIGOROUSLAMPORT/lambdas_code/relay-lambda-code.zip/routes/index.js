const express = require('express');
const axios = require('axios');
const AWS = require('aws-sdk');
const fs = require('fs');
const https = require('https');
const IpCidr = require('ip-cidr');

const certificateIpMapping = require('../certificate-ip-mapping.json');
require('dotenv').config();

const router = express.Router();

router.get('/' + process.env.CUSTOMER + '/ping', (req, res) => {
  res.status(200).send({ response: 'pong' }); // developer for customer responded that inContact can only ingest JSON responses
});

const apiSecretModifier = (req, res) => {
  let secretsManager = new AWS.SecretsManager();
  AWS.config.update({
    region: process.env.REGION,
  });
  if (req.body && req.body.secretKey) {
    const set_env = process.env.AWS_LAMBDA_FUNCTION_NAME.split('-')[1];

    secretsManager
      .updateSecret({
        SecretId: 'cr-secret-' + process.env.CUSTOMER + '-' + set_env,
        SecretString: req.body.secretKey,
      })
      .promise()
      .then(() => {
        res.status(200).send({ message: 'Updated successfully.' });
      })
      .catch((err) => {
        res.status(500).send({ error: err.message });
      });
  } else {
    res.status(400).send({ error: 'secretKey missing.' });
  }
};

router.post('/' + process.env.CUSTOMER + '/apisecret', apiSecretModifier);
router.put('/' + process.env.CUSTOMER + '/apisecret', apiSecretModifier);

router.use(async (req, res) => {
  try {
    console.log('Incoming request:', req);
    console.log('Incoming request body:', req.body);

    let h = req.headers;
    let uri = req.headers['Relay-Target'] || req.headers['relay-target'];

    delete h['relay-target'];
    delete h['Relay-Target'];
    delete h['x-api-key'];
    delete h['x-api-secret'];
    delete h['cookie'];
    delete h['accept-encoding'];
    delete h['host'];
    delete h['content-length'];

    let agentOptions = {};
    let mappingFound = false;
    if (certificateIpMapping.length > 0) {
      let hostName = extractHostNameFromURL(uri);
      console.log(hostName, 'hostName');
      const isIP = isIPAddress(hostName);
      console.log(isIP, 'isIP');
      let certificateConfig = certificateIpMapping.find((e) => e.relayTarget.includes(hostName));
      if (!certificateConfig && isIP == true) {
        certificateConfig = certificateIpMapping.find((mapping) => isIpBelongsToCidr(mapping.relayTarget, hostName));
      }
      if (certificateConfig) {
        mappingFound = true;
        const { certificatePath, certificateKeyPath, pfxCertificatePath, certificatePassPhrase } = certificateConfig;

        if (certificatePath) {
          agentOptions.cert = fs.readFileSync(certificatePath).toString();
        }
        if (certificateKeyPath) {
          agentOptions.key = fs.readFileSync(certificateKeyPath).toString();
        }
        if (pfxCertificatePath) {
          agentOptions.pfx = fs.readFileSync(pfxCertificatePath);
        }
        if (certificatePassPhrase) {
          agentOptions.passphrase = certificatePassPhrase;
        }
      }
    }
    if (process.env.SENDCERTIFICATE == 'true' && mappingFound == false) {
      if (process.env.CERTIFICATEPATH && process.env.CERTIFICATEPATH != '') {
        agentOptions.cert = fs.readFileSync(process.env.CERTIFICATEPATH).toString();
      }
      if (process.env.CERTIFICATEKEYPATH && process.env.CERTIFICATEKEYPATH != '') {
        agentOptions.key = fs.readFileSync(process.env.CERTIFICATEKEYPATH).toString();
      }
      if (process.env.PFXCERTIFICATEPATH && process.env.PFXCERTIFICATEPATH != '') {
        agentOptions.pfx = fs.readFileSync(process.env.PFXCERTIFICATEPATH);
      }
      if (process.env.CERTIFICATEPASSPHRASE && process.env.CERTIFICATEPASSPHRASE != '') {
        agentOptions.passphrase = process.env.CERTIFICATEPASSPHRASE;
      }
    }
    const httpsAgent = new https.Agent(agentOptions);

    let newUriResource = req.url;

    if (req.url.startsWith('/' + process.env.CUSTOMER + '/')) {
      newUriResource = req.url.split(process.env.CUSTOMER);
      newUriResource.splice(0, 1);
    }

    if (req.url.charAt(0) != '/') {
      newUriResource = req.url.split(process.env.STAGE);

      newUriResource.splice(0, 1);
      newUriResource = newUriResource.join(process.env.STAGE);
    }

    uri = `${uri}${newUriResource}`;

    console.log('uri with relay base url', uri);

    let axiosRequest = {
      method: req.method,
      url: uri,
      headers: h,
      httpsAgent,
    };

    if (Buffer.isBuffer(req.body)) {
      axiosRequest.data = req.body.toString('utf-8');
    } else if (req.body) {
      axiosRequest.data = req.body;
    }

    // if (
    //   req.method.toUpperCase() == "POST" ||
    //   req.method.toUpperCase() == "PUT" ||
    //   req.method.toUpperCase() == "PATCH"
    // ) {
    //   if (Buffer.isBuffer(req.body)) {
    //     axiosRequest.data = req.body.toString("utf-8");
    //   } else if (req.body) {
    //     axiosRequest.data = req.body;
    //     if (h["content-type"] == "application/json") {
    //       axiosRequest.headers["content-length"] = JSON.stringify(
    //         axiosRequest.data
    //       ).length;
    //     }
    //   }
    // }

    console.log('Request sent to relay target:', axiosRequest);
    console.log('Request body sent to relay target:', axiosRequest.data);
    let request = await axios(axiosRequest);
    console.log('Relay response', request);
    formatAxiosResponse(res, request);
  } catch (e) {
    console.log('Error in relay', e);
    formatAxiosResponse(res, e.response);
  }
});

const formatAxiosResponse = (res, response) => {
  try {
    if (response && response.headers) {
      delete response.headers['transfer-encoding'];
      res.set(response.headers);
    }

    console.log('response', response);
    if (response && response.status && response.status < 400) {
      res.set('x-relay-status', 'ok');
      res.status(response.status).send(response && response.data ? response.data : '');
    } else {
      console.log('Response error from relay target:', response);
      res.set('x-relay-status', 'failed');
      res.status(response ? response.status : 500).send(response && response.data ? response.data : '');
    }
  } catch (e) {
    res.status(500).send('Internal server error');
  }
};

const isIpBelongsToCidr = (cidr, address) => {
  try {
    if (!IpCidr.isValidCIDR(cidr)) {
      return false;
    }
    const cidrRange = new IpCidr(cidr);
    return cidrRange.contains(address.replace(/(^\w+:\/\/|:\d+$)/g, ''));
  } catch (e) {
    return false;
  }
};

const isIPAddress = (input) => {
  const ipv4Regex =
    /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  return ipv4Regex.test(input);
};

const extractHostNameFromURL = (input) => {
  try {
    const { hostname } = new URL(input);
    return hostname;
  } catch (e) {
    return input;
  }
};

module.exports = router;
