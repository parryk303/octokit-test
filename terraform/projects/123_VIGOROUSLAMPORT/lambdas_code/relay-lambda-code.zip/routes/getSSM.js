let getSecret = async (secretName) => {

    const secretFromExtension = await callSecretsManagerExtension(secretName);
    return secretFromExtension.SecretString

};

function callSecretsManagerExtension(secretId) {

    const http = require('http');
    
  
    const options = {
       hostname: 'localhost',
       port: 2773,
       path: '/secretsmanager/get?secretId=' + encodeURIComponent(secretId),
       headers: {
           'X-Aws-Parameters-Secrets-Token': process.env.AWS_SESSION_TOKEN
       },
       method: 'GET'
   };
   
   return new Promise((resolve, reject) => {
     const req = http.get(options, res => {
       let rawData = '';
 
       res.on('data', chunk => {
         rawData += chunk;
       });
 
       res.on('end', () => {
         try {
           resolve(JSON.parse(rawData));
         } catch (err) {
           reject(new Error(err));
         }
       });
     });
 
     req.on('error', err => {
       reject(new Error(err));
     });
   });
}


module.exports = { getSecret };