const SecretsManager = require('./getSSM.js');

let validateToken = async (token, callback, event) => {
  var set_env = process.env.AWS_LAMBDA_FUNCTION_NAME.split("-")[1]
  var secretName = "cr-secret-" + process.env.CUSTOMER + "-" + set_env
  var apiValue = await SecretsManager.getSecret(secretName);
  
  
  if (token != apiValue) {
    return callback('Unauthorized');
  } else {
    return callback(null, generatePolicy(token, 'Allow', event.methodArn));
  }
};

const generatePolicy = (principalId, effect, resource, authContext = null) => {
  const authResponse = {};
  authResponse.context = authContext;

  authResponse.principalId = principalId;
  if (effect && resource) {
    const policyDocument = {};
    policyDocument.Version = '2012-10-17';
    policyDocument.Statement = [];
    const statementOne = {};
    statementOne.Action = 'execute-api:Invoke';
    statementOne.Effect = effect;
    statementOne.Resource = resource;
    policyDocument.Statement[0] = statementOne;
    authResponse.policyDocument = policyDocument;
  }
  return authResponse;
};

module.exports = { validateToken };