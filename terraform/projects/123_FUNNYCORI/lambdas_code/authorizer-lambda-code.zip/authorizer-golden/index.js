var authService = require('./service/authService');

let authorization = (event, context, callback) => {
  var token = event.authorizationToken; // moving outside of try so can be logged in catch
  try {
    if (!token) return callback('Unauthorized - no token provided'); // more info in error

    return authService.validateToken(token, callback, event);
  } catch (e) {
    console.error(`Invalid token. Token supplied in event: ${token}`) // more info for our log
    return callback('Unauthorized');
  }
};

exports.handler = authorization;
