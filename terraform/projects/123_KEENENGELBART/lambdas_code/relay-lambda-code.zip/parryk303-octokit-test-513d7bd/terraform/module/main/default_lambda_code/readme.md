# Multiple Security Certs support

relay-golden.zip code contains a file named "certificate-ip-mapping.json" in root which can be used to configure multiple security certs for different environments. relay-golden code also contains another file named "certificate-ip-mapping.json.sample" in root which can be referred for example configurations. 